#
# Copyright (c) 2012-2020 Snowflake Computing Inc. All right reserved.
#
